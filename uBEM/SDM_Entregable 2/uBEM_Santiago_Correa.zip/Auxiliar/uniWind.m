function uniWind = uniWind(t, y, Vhub)

  uniWind = [Vhub, 0, 0]' ;
  
end